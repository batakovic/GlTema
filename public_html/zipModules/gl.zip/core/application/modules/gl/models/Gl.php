<?php

class Gl{
    
    public static function init(){
        
        
    }
}
?>
