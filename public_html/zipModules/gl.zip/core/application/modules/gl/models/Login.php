<?php

use GitHub\API\User\User;
use GitHub\API\User\Email;

class Login
{
        public static function generateCurlData($values)
        {
            $xmlFile = APPLICATION_PATH . '/configs/application.xml';
            $xmlobj = simplexml_load_file($xmlFile);

            $clientID = $xmlobj->production->clientID["value"];
            $clientSecret = $xmlobj->production->clientSecret["value"];
            
            $code= urlencode($values['code']);
            
            $data = 'client_id=' . $clientID . '&' .
		    'client_secret=' . $clientSecret. '&' .
		    'code=' . $code;   
            
            return $data;
            
        }
        
        public static function getUser($access_token)
        {            
            $user=\User::getInfoByToken($access_token);            
            return $user;           
        }
        
        public static function getGitHubUserInfo($userGit)
        {             
            $userGit->login();        
            $userInfo=$userGit->get();            
            $userInfoDecoded= Zend_Json::decode($userInfo);
            return $userInfoDecoded;
           
        }
        
        public static function getUserEmail($userGit,$access_token)
        {
            $emails = $userGit->emails()->all("$access_token");
            //$userGit->setCredentials(new GitHub\API\Authentication\OAuth("$access_token"));
            $emailDecoded=  Zend_Json::decode($emails);
            return $emailDecoded[0];
        }
        
        public static function createUser($values)
        {
            \User::createNewUser($values);
        }
        
        
        public static function loginUser($userEmail, $password)
        {
            return \User::login($userEmail, $password);
        }
        
        public static function processGenerateLicense($response)
        {            
            $translate = Zend_Registry::getInstance()->Zend_Translate;
            
            $licenseKey="";
            
            $xmlFile = simplexml_load_string($response);
            $json = Zend_Json::encode($xmlFile);
            $response = Zend_Json::decode($json, TRUE);
            
            try {
                if($response['status'] === "0")
                {
                    throw new Exception ($response['message']);
                }
                else
                {
                    unset($response['status']);
                    unset($response['message']);
                }
                
                foreach ($response as $procces => $values)
                    {
                        $licenseKey=$values['licenseKey'];
                    }
                    return $licenseKey;
                
            } catch (Exception $e) {
                echo $translate->_($e->getMessage());
            }
                    
        }
        
        public static function checkLicense($access_token)
        {
             $user=\User::getInfoByToken($access_token);
             
             $licenseKey=$user->license_key;
             
             return $licenseKey;
        }
        
        public static function addLicenseToUser($licenseKey, $access_token)
        {
            $user=\User::getInfoByToken($access_token);
            
            $user->license_key=$licenseKey;
            $user->save();
        }
        
}


?>
