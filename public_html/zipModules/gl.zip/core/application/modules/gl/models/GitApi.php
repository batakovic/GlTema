<?php

class GitApi
{
    public static function gitConnect($url, $username, $password, $options = array())
    {
        
        if (count($options))
            $url = self::createUrl($url, $options);
        $c = curl_init();
        
        curl_setopt($c, CURLOPT_URL, $url);
        curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($c, CURLOPT_USERPWD, "$username:$password");        
        if ($options["inputPost"])
            curl_setopt($c, CURLOPT_POSTFIELDS, Zend_Json::encode($options["inputPost"]));      
        curl_setopt($c, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($c, CURLOPT_SSL_VERIFYPEER, 0);        
        $response = curl_exec($c);        
        curl_close($c);
        
        var_dump($response);
        die();
        $response = Zend_Json::decode($response);

        if (false) {
            $responseInfo = curl_getinfo($c);
            $httpCode = $responseInfo['http_code'];
            $validator = new Zend_Validate_Between(array("min" => 400, "max" => 505));
            if ($validator->isValid($httpCode)) {
                return array("error" => $httpCode . " : " . self::$httpResponseMessages[$httpCode]);
            } else {
                return array("error" => $httpCode);
            }
        } else {
            return $response;
        }
    }
    
    public static function createUrl($url, $options) {
      foreach($options as $key => $option){
        $url = str_replace("{[$key]}", $option, $url);
      }
      
      $i=0;
      if(count($options["input"])){
        foreach ($options["input"] as $key => $input){
          if($i==0)
            $url .="?$key=$input";
          else
            $url .="&$key=$input";
          $i++;
        }
      }
      return $url;
    }

}

?>
