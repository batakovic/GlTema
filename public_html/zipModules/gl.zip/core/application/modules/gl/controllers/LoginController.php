<?php

use GitHub\API\User\User;

class Gl_LoginController extends Zend_Controller_Action {

    protected $_access_token;
    protected $_username;
    protected $_mainEmail;

    // const URL_PATH= "garden.propulsionapps.com/garden/api/generatelicense";

   // const URL_PATH = "madic.propulsionplatform.com/platforma/public_html/garden/api/";
    const URL_PATH = "http://garden.propulsionapps.com/garden/api/";
    const CREDENTIALS = "dev:yvdv217w";

    public function init() {

        $this->_helper->layout()->setLayout('wide');

        $request = $this->getRequest();
        $values = $request->getParams();

        $this->view->values = $values;
        $this->view->module = $_SESSION["module"] = $values["module"];
        $this->view->controller = $_SESSION["controller"] = $values["controller"];
        $this->view->action = $_SESSION["action"] = $values["action"];
    }

    public function loginAction() {
        
    }

    public function oauthAction() {

        //GITHUB LOGIN
        $request = $this->getRequest();
        $values = $request->getParams();
        $data = Login::generateCurlData($values);

        $ch = curl_init('https://github.com/login/oauth/access_token');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);

        curl_close($ch);
        preg_match('/access_token=([0-9a-f]+)/', $response, $out);



        $access_token = "";
        if (isset($out[1])) {
            $access_token = $out[1];
        }


        $userGit = new User();        
        $userGit->setCredentials(new GitHub\API\Authentication\OAuth("$access_token"));
        
        $userInfo = Login::getGitHubUserInfo($userGit);
        
        $userEmail = Login::getUserEmail($userGit, $access_token);
        
        if(!is_null( $userInfo['name'])){
            $name = $userInfo['name'];
        }else{
            $name = "";
        }
         
        if(!is_null( $userInfo['company'])){
            $company = $userInfo['company'];
        }else{
            $company = "null";
        }
        

        $username = $userInfo['login'];        
        $password = $username . $access_token;

        $user = Login::getUser($access_token);


        if (is_null($user)) {
            $values = array("username" => $username, "email" => $userEmail, "fullname"=>$name, "company"=>$company, "role_id" => 4, "token" => $access_token, "password" => md5($password));
            Login::createUser($values);
        }

        $isLoggedIn = Login::loginUser($userEmail, $password);
        
        //              //GITHUB LOGIN
        if ($isLoggedIn) {
            $referer = $_SERVER['HTTP_REFERER'];
            $strpos = strpos($referer, '/content/article/');
            $referer = substr($referer, $strpos);
            $this->_redirect($referer);
        } else {
            $this->_redirect('/content/article/page/home');
        }
    }

}

?>