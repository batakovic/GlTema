<?php
/**
* Error controller.
* 
* This controller handles the display of various exceptions thrown by the application.
*
*
* LICENSE: Commercial
* 
* @package CORE
* @subpackage Controllers
* @copyright Ivan Dudas, Human Made, 2011
* @license http://humanmade.rs/core/license
* @version  1.0.0
* @link  http://humanmade.rs/core
* @since 2010
*/

/**
* Error controller.
* 
* This controller handles the display of various exceptions thrown by the application.
*
*
* LICENSE: Commercial
* 
* @package CORE
* @subpackage Controllers
* @copyright Ivan Dudas, Human Made, 2011
* @license http://humanmade.rs/core/license
* @version  1.0.0
* @link  http://humanmade.rs/core
* @since 2010
*/
class ErrorController extends Platforma_Controller_Action
{
    /**
    * This function determines the error type and based on it displays a different error message to the user. It also handles 404 requests
    *  
    */
    public function errorAction()
    {        
        $this->view->adminTheme =  Core::getObjectRow("Theme",Core::getObjectSelect("Theme")->where("admin_theme=?",1));
        
        $errors = $this->_getParam('error_handler');
        $this->translate = Zend_Registry::getInstance()->Zend_Translate;
        $translate = $this->translate;
        
        if (Zend_Auth::getInstance()->hasIdentity()) {
            $info   = Zend_Auth::getInstance()->getIdentity();
            $acl    = Zend_Registry::getInstance()->acl;
            
            $user = Core::getObjectRow("User", Core::getObjectSelect("User",false)->where("email=?", $info->email));

            $this->role_id  = $user->role_id;
            $this->user     = $user;
            $this->user_id  = $user->id;

            if (Role::adminPanel($user->role_id)){
                $isAdmin = true;
            } else {
                $isAdmin = false;
            }
        } else {
            $isAdmin = false;
        }
        switch ($errors->type) {

            case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ROUTE:                
            case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_CONTROLLER:                
            case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ACTION:
                /*
                    404 error
                */        
                if($isAdmin){
                    $this->_helper->layout()->setLayout('blank');
                    $this->view->layout = $this->_helper->layout();                    
                } else {
                    $this->_helper->layout()->setLayout('blank');
                }
                
                //Get error row
                $error = ErrorControll::getErrorRow(404);
                
                $this->getResponse()->setHttpResponseCode(404);    
                if($error->debug_info == 1){
                    
                    $this->view->message     = $error->text;
                    $this->view->exception   = $errors->exception;
                    $this->view->traceString = $errors->exception->getTraceAsString();
                    $this->view->request     = $errors->request;
                    
                } else {
                    $this->view->message = $error->text;
                }
                break;
                
            default:  
            
                if($isAdmin){
                    $this->_helper->layout()->setLayout('blank');                    
                    $this->view->layout = $this->_helper->layout();
                } else {
                      $this->_helper->layout()->setLayout('blank');  
                }
                $message = $errors->exception->getMessage();
                @list($type,$msg) = explode(":::",$message);
                if($type == "warn") {
                    $this->_helper->layout()->disableLayout();
                    $this->view->warn    = true;
                    $this->view->message = $msg;
                    $_SESSION["notificationMessage"] = $msg;                    
                } else {
                    //Get error row
                    $error = ErrorControll::getErrorRow(500);

                    if($error->debug_info == 1){
                        $this->view->message     = $error->text;
                        $this->view->exception   = $errors->exception;
                        $this->view->traceString = $errors->exception->getTraceAsString();
                        $this->view->request     = $errors->request;
                    }else{
                        $this->view->message = $error->text;
                    } 
                }
                break;
        }
        
        $this->view->translate   = $this->translate;
      
    }
    /**
    * This function is used in core for handeling error page's and gives user oportunity to change display text for error's 404 and 500. And change debug mode.
    *  
    */
    public function errorcontrollAction()
    {
        $this->_helper->layout ()->setLayout ('wide');
        $errors                 = $this->_getParam('error_handler');
        $this->translate        = Zend_Registry::getInstance()->Zend_Translate;
        $translate              = $this->translate;
        $request                = $this->getRequest();
        $values                 = $request->getParams();
        $success = false;
        if(isset($values['errorText404'])){
            $success = ErrorControll::setErrors($values);
        }    
        
        $allErrors = Core::getObjects("ErrorControll");
           
        $this->view->success     = $success;
        $this->view->allerrors   = $allErrors; 
        $this->view->translate   = $this->translate; 
        $this->view->sectionName    = $this->translate->_("Error Pages Settings");
        $this->view->subsectionName    = "";
    }
    
}