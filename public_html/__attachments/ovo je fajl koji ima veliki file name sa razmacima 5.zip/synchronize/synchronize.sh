#!/bin/bash
#
# Continuously synchronize local and remote directory
# Copyright (c)  Petr Baudis <pasky@ucw.cz>  2012

cd $(dirname "$0")

debug=
manual=
while [ -n "$1" ]; do
	case "$1" in
		-d) debug=1;;
		-m) manual=1;;
		*) break;;
	esac
	shift
done

sourcedir=$1
target=$2
excludes="./excludes"

RSYNC="rsync --delete -Pva"
timeout="1"

if [ ! -d "$sourcedir" -o "${target#*:}" = "${target%%:*}" -o $# -ne 2 ]; then
	echo "Usage: $0 [-d] [-m] SOURCEDIR USER@HOST:REMOTEDIR" >&2
	exit 1
fi

# Sanitize locale settings
export LC_ALL=C

synchronize() {
	if [ -s "$excludes" ]; then
		$RSYNC --exclude-from "$excludes" "$sourcedir" "$target"
	else
		$RSYNC "$sourcedir" "$target"
	fi
}

if [ -n "$manual" ]; then
	while true; do
		echo -n "Press enter to refresh..."
		read x
		synchronize
	done
fi

lastprompt=
while true; do
	./notifywait "$sourcedir"
	perl -le 'select(undef, undef, undef, 0.1)' # Poor Man's sleep 0.1
done |
while true; do
	prompt=
	read -t $timeout prompt
	[ -z "$debug" ] || echo " . $prompt"

	if [ -n "$prompt" ]; then
		lastprompt=$prompt
		continue;
	fi
	if [ -z "$lastprompt" ]; then
		continue;
	fi
	lastprompt=

	synchronize
done
